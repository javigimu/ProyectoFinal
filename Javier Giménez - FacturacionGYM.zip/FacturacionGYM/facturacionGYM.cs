﻿// Proyecto final FacturacionGYM
// Javier Giménez Muñoz


class facturacionGYM
{
    public static void Main()
    {
        GestionGYM g = new GestionGYM();
        g.Lanzar();
    }
}
