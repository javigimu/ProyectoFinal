﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.IO;

class ExportadorDeArchivos
{
    const string DIRECTORIO_PDF = "listados/pdf/";
    const string DIRECTORIO_PDF_ARTICULOS = "listados/pdf/articulos/";
    const string DIRECTORIO_PDF_USUARIOS = "listados/pdf/usuarios/";
    const string DIRECTORIO_PDF_TICKETS = "listados/pdf/tickets/";
    public void ExportarAPdf(ListaDeArticulos articulos)
    {
        DateTime fechaActual = DateTime.Now;
        GestorPantalla gp = new GestorPantalla();

        try
        {
            if (!Directory.Exists(DIRECTORIO_PDF))
            {
                Directory.CreateDirectory(DIRECTORIO_PDF);
            }
            if (!Directory.Exists(DIRECTORIO_PDF_ARTICULOS))
            {
                Directory.CreateDirectory(DIRECTORIO_PDF_ARTICULOS);
            }

            // crear el fichero pdf
            Document doc = new Document();
            doc.SetMargins(40f, 40f, 40f, 40f);
            doc.AddAuthor("Javier Giménez");
            doc.AddTitle("Artículos a " + fechaActual.ToString("dd/MM/yyyy"));

            string f = "articulos_" + fechaActual.ToString("dd-MM-yyyy");
            PdfWriter.GetInstance(doc, new FileStream(DIRECTORIO_PDF_ARTICULOS
                + f + ".pdf", FileMode.Create));
            doc.Open();

            // añadir título
            Paragraph titulo = new Paragraph();
            titulo.Font = FontFactory.GetFont(FontFactory.TIMES, 18f,
                BaseColor.BLUE);
            titulo.Add("Artículos a " + fechaActual.ToString("dd/MM/yyyy"));
            doc.Add(titulo);

            doc.Add(new Paragraph (" "));

            float[] anchoCeldas = { 10, 50, 20, 20 };
            PdfPTable tabla = new PdfPTable(anchoCeldas) { WidthPercentage = 100 };

            tabla.AddCell(new PdfPCell(new Phrase("Código"))
            { 
                BackgroundColor = BaseColor.CYAN, 
                HorizontalAlignment=1
            });
            tabla.AddCell(new PdfPCell(new Phrase("Detalle"))
            {
                BackgroundColor = BaseColor.CYAN,
                HorizontalAlignment = 3
            });
            tabla.AddCell(new PdfPCell(new Phrase("Precio"))
            {
                BackgroundColor = BaseColor.CYAN,
                HorizontalAlignment = 2
            });
            tabla.AddCell(new PdfPCell(new Phrase("Stock"))
            {
                BackgroundColor = BaseColor.CYAN,
                HorizontalAlignment = 2
            });

            foreach (Articulo a in articulos.Articulos)
            {
                tabla.AddCell(new PdfPCell(new Phrase(a.Codigo.ToString("####")))
                {
                    HorizontalAlignment = 1
                });

                string textoActividad = "";
                if (a is Actividad)
                    textoActividad = "Actividad: ";
                textoActividad += a.Detalle;
                tabla.AddCell(new PdfPCell(new Phrase(textoActividad))
                {
                    HorizontalAlignment = 3
                });
                tabla.AddCell(new PdfPCell(new Phrase(
                    a.Precio.ToString("0.00")))
                {
                    HorizontalAlignment = 2
                });
                tabla.AddCell(new PdfPCell(new Phrase("" + a.Stock))
                {
                    HorizontalAlignment = 2
                });
            }
            doc.Add(tabla);
            doc.Close();
            
            gp.EscribirExportacionCorrecta();
        }
        catch (PathTooLongException) { }
        catch (IOException) { }
        catch (Exception) { }
    }

    public void ExportarAPdf(ListaDeUsuarios usuarios)
    {
        DateTime fechaActual = DateTime.Now;
        GestorPantalla gp = new GestorPantalla();

        try
        {
            if (!Directory.Exists(DIRECTORIO_PDF))
            {
                Directory.CreateDirectory(DIRECTORIO_PDF);
            }
            if (!Directory.Exists(DIRECTORIO_PDF_USUARIOS))
            {
                Directory.CreateDirectory(DIRECTORIO_PDF_USUARIOS);
            }

            // crear el fichero pdf
            Document doc = new Document();
            doc.SetMargins(40f, 40f, 40f, 40f);
            doc.AddAuthor("Javier Giménez");
            doc.AddTitle("Usuarios a " + fechaActual.ToString("dd/MM/yyyy"));

            string f = "usuarios_" + fechaActual.ToString("dd-MM-yyyy");
            PdfWriter.GetInstance(doc, new FileStream(DIRECTORIO_PDF_USUARIOS
                + f + ".pdf", FileMode.Create));
            doc.Open();

            // añadir título
            Paragraph titulo = new Paragraph();
            titulo.Font = FontFactory.GetFont(FontFactory.TIMES, 18f,
                BaseColor.BLUE);
            titulo.Add("Usuarios a " + fechaActual.ToString("dd/MM/yyyy"));
            doc.Add(titulo);
            doc.Add(new Paragraph(" "));

            // añadir la líneas de datos
            foreach (Usuario u in usuarios.Usuarios)
                doc.Add(new Paragraph(u.ToString()));

            doc.Close();

            gp.EscribirExportacionCorrecta();
        }
        catch (PathTooLongException) { }
        catch (IOException) { }
        catch (Exception) { }
    }

    public void ExportarAPdf(ListaDeTickets tickets, ListaDeUsuarios usuarios,
        ListaDeArticulos articulos)
    {
        DateTime fechaActual = DateTime.Now;
        GestorPantalla gp = new GestorPantalla();

        try
        {
            if (!Directory.Exists(DIRECTORIO_PDF))
            {
                Directory.CreateDirectory(DIRECTORIO_PDF);
            }
            if (!Directory.Exists(DIRECTORIO_PDF_TICKETS))
            {
                Directory.CreateDirectory(DIRECTORIO_PDF_TICKETS);
            }

            // crear el fichero pdf
            Document doc = new Document();
            doc.SetMargins(40f, 40f, 40f, 40f);
            doc.AddAuthor("Javier Giménez");
            doc.AddTitle("Tickets a " + fechaActual.ToString("dd/MM/yyyy"));

            string f = "tickets_" + fechaActual.ToString("dd-MM-yyyy");

            PdfWriter.GetInstance(doc, new FileStream(DIRECTORIO_PDF_TICKETS
                + f + ".pdf", FileMode.Create));
            doc.Open();

            // añadir título
            Paragraph titulo = new Paragraph();
            titulo.Font = FontFactory.GetFont(FontFactory.TIMES, 18f,
                BaseColor.BLUE);

            titulo.Add("Tickets a " + fechaActual.ToString("dd/MM/yyyy"));
            doc.Add(titulo);

            doc.Add(new Paragraph(" "));
            
            foreach (Ticket t in tickets.Tickets)
            {
                doc.Add(new Paragraph(t.Codigo));
                doc.Add(new Paragraph(t.FechaFormateada()));
                doc.Add(new Paragraph(usuarios.GetUsuario(t.Codigo).Nombre));
                if (articulos.Articulos.Count > 0)
                {
                    foreach (KeyValuePair<int, int> a in t.Articulos)
                    {
                        Articulo articulo = 
                            articulos.ObtenerArticuloPorCodigo(a.Key);
                        if (articulo != null)
                        {
                            doc.Add(new Paragraph(articulo.Detalle +
                                " (" + a.Value + ")"));
                        }
                    }
                }
            }
            doc.Close();            

            gp.EscribirExportacionCorrecta();
        }
        catch (PathTooLongException) { }
        catch (IOException) { }
        catch (Exception) { }
    }
}