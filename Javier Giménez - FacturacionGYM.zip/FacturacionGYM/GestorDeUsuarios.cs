﻿using System;
using System.Threading;

class GestorDeUsuarios
{
    private const string FICHERO_USUARIOS = "datos/usuarios.txt";
    
    private ListaDeUsuarios usuarios = new ListaDeUsuarios();
    private string[] opcionesUsuario = {"Añadir", "Buscar", "Modificar",
        "Borrar", "Menu principal"};
    private GestorPantalla gp = new GestorPantalla();
    const int XLISTADO = 5;
    const int YLISTADO = 6;
    const int XDATO = 50;
    const int YDATO = 6;
    const int XMAXIMA = 110;

    public ListaDeUsuarios GetListaDeUsuarios() { return usuarios;  }
    public void SetListaDeUsuarios(ListaDeUsuarios usuarios)
    {
        this.usuarios = usuarios;
    }

    // Estructura del fichero de usuarios: codigo;nombre;dni;telefono
    public void InicializarUsuarios()
    {
        usuarios.CargarUsuarios(FICHERO_USUARIOS);
    }

    public void MostrarPantallaUsuarios(int usuarioActual)
    {
        Console.BackgroundColor = gp.ColorFondoOriginal;
        Console.ForegroundColor = gp.ColorTextoOriginal;
        Console.Clear();
        GestionGYM.MostrarCabecera();
        GestionGYM.MostrarMenu(opcionesUsuario);

        gp.MostrarUsuarios(XLISTADO, YLISTADO, ref usuarioActual, usuarios);
        gp.MostrarUsuarioActual(XDATO, YDATO, usuarioActual, usuarios);
        gp.MostrarExportar();

        bool volverAlMenuPrincipal;
        do
        {
            int opcion = RecogerOpcionUsuario(ref usuarioActual);
            volverAlMenuPrincipal = EjecutarOpcionUsuario(opcion, usuarioActual);
        }
        while (!volverAlMenuPrincipal);
        GestionGYM.LanzarPantallaPrincipal();
        //GestionGYM.MostrarBienvenida();
    }

    public bool EjecutarOpcionUsuario(int opcion, int usuarioActual)
    {
        bool volverAlMenuPrincipal = false;
        gp.ColorTexto = ConsoleColor.Black;

        switch (opcion)
        {
            case 0: Exportar(); break;
            case 1: AnyadirUsuario(ref usuarioActual); break;
            case 2: BuscarUsuario(ref usuarioActual); break;
            case 3: ModificarUsuario(usuarioActual); break;
            case 4: BorrarUsuario(ref usuarioActual); break;
            case 5: volverAlMenuPrincipal = true; break;
        }
        return volverAlMenuPrincipal;
    }

    public void Exportar()
    {
        ExportadorDeArchivos exportar = new ExportadorDeArchivos();
        exportar.ExportarAPdf(usuarios);
    }

    public void BorrarUsuario(ref int usuarioActual)
    {
        usuarios.BorrarUsuario(ref usuarioActual);
        usuarios.GuardarUsuarios(FICHERO_USUARIOS);
        MostrarPantallaUsuarios(usuarioActual);
    }

    public void ModificarUsuario(int usuarioActual)
    {
        gp.BorrarDatosUsuario(XDATO, YDATO);
        string nombre = gp.Pedir(XDATO, YDATO, XMAXIMA, "Nombre: ",
            ConsoleColor.Black, usuarios.Usuarios[usuarioActual].Nombre);
        string DNI = gp.Pedir(XDATO, YDATO + 2, XMAXIMA, "DNI: ",
            ConsoleColor.Black, usuarios.Usuarios[usuarioActual].DNI);
        int numTelefono;
        do
        {
            string telefono = gp.Pedir(XDATO, YDATO + 4, XMAXIMA, "Teléfono: ",
                ConsoleColor.Black, "" + usuarios.Usuarios[usuarioActual].Telefono);
            if (!Int32.TryParse(telefono, out numTelefono))
                numTelefono = -1;
        }
        while (numTelefono == -1);
        byte descuento = Convert.ToByte(gp.Pedir(XDATO, YDATO + 6, XMAXIMA,
            "Descuento: ", ConsoleColor.Black, " "
            + usuarios.Usuarios[usuarioActual].Descuento));

        usuarios.Modificar(usuarioActual, nombre, DNI, numTelefono, descuento);
        usuarios.GuardarUsuarios(FICHERO_USUARIOS);
        MostrarPantallaUsuarios(usuarioActual);
    }

    public void BuscarUsuario(ref int usuarioActual)
    {
        gp.BorrarDatosUsuario(XDATO, YDATO);
        gp.Escribir(XDATO, YDATO, "Nombre: ", ConsoleColor.Black);
        string nombre = Console.ReadLine();

        usuarioActual = usuarios.ObtenerUsuario(nombre);
        if (usuarioActual >= 0)
            MostrarPantallaUsuarios(usuarioActual);
        else
        {
            gp.BorrarDatosUsuario(XDATO, YDATO);
            gp.Escribir(XDATO, YDATO, "Usuario no encontrado",
                ConsoleColor.DarkRed);
            Thread.Sleep(3000);
            BuscarUsuario(ref usuarioActual);
        }
    }

    public void AnyadirUsuario(ref int usuarioActual)
    {
        gp.BorrarDatosUsuario(XDATO, YDATO);
        int codigo = usuarios.getUltimoCodigo();       
        string nombre = gp.Pedir(XDATO, YDATO, XMAXIMA, "Nombre: ",
           ConsoleColor.Black);

        string DNI = gp.Pedir(XDATO, YDATO, XMAXIMA, "DNI: ", ConsoleColor.Black);
        int numTelefono;
        do
        {
            string telefono = gp.Pedir(XDATO, YDATO, XMAXIMA, "Teléfono: ",
                ConsoleColor.Black);
            if (!Int32.TryParse(telefono, out numTelefono))
                numTelefono = -1;
        }
        while (numTelefono == -1);    
        
        usuarios.AnyadirUsuario(new Usuario(codigo, nombre, DNI, numTelefono));
            usuarios.GuardarUsuarios(FICHERO_USUARIOS);
        usuarioActual = 0;
        MostrarPantallaUsuarios(usuarioActual);
    }

    public int RecogerOpcionUsuario(ref int usuarioActual)
    {
        int opcion = -1;
        ConsoleKeyInfo tecla;

        if (Console.KeyAvailable)
        {
            tecla = Console.ReadKey(true);
            if (tecla.KeyChar >= '0' && tecla.KeyChar <= '5')
                opcion = (byte)(tecla.KeyChar - '0');
            else if (tecla.Key == ConsoleKey.DownArrow)
            {
                if (usuarioActual < usuarios.Usuarios.Count - 1)
                {
                    usuarioActual++;
                    MostrarPantallaUsuarios(usuarioActual);
                }
            }
            else if (tecla.Key == ConsoleKey.UpArrow)
            {
                if (usuarioActual > 0)
                {
                    usuarioActual--;
                    MostrarPantallaUsuarios(usuarioActual);
                }
            }
        }
        return opcion;
    }

    public byte RecogerOpcion()
    {
        byte opcion = 0;
        ConsoleKeyInfo tecla;

        if (Console.KeyAvailable)
        {
            tecla = Console.ReadKey(true);
            if (tecla.KeyChar >= '1' && tecla.KeyChar <= '6')
                opcion = (byte)(tecla.KeyChar - '0');
        }
        return opcion;
    }

    public bool Salir()
    {
        return true;
    }
}