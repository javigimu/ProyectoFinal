﻿class Actividad : Articulo
{
    public Actividad (int codigo, string detalle, float precio)
        :base(codigo, detalle, precio, -1)
    {

    }


}