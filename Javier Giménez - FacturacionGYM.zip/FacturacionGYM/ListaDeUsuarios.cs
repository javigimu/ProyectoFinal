﻿using System;
using System.Collections.Generic;
using System.IO;

class ListaDeUsuarios 
{
    public List<Usuario> Usuarios { get; set; }
    
    public ListaDeUsuarios()
    {
        Usuarios = new List<Usuario>();
    }

    public void AnyadirUsuario(Usuario u)
    {
        Usuarios.Add(u);
    }

    public void BorrarUsuario(ref int usuarioActual)
    {
        Usuarios.Remove(Usuarios[usuarioActual]);
        usuarioActual = 0;
    }

    public void Modificar(int usuarioActual, string nombre, string DNI, 
        int telefono, byte descuento)
    {
        Usuarios[usuarioActual].Nombre = nombre;
        Usuarios[usuarioActual].DNI = DNI;
        Usuarios[usuarioActual].Telefono = telefono;  
        Usuarios[usuarioActual].Descuento = descuento;  
    }

    // devuelve el usuario anterior o siguiente o el mismo si no se puede obtener
    // opcion 1 -> anterior y opcion 2 -> siguiente
    public void ObtenerCodigoUsuario(ref int usuarioActual, int opcion)
    {
        switch (opcion)
        {
            case 1:
                if (usuarioActual > 0)
                    usuarioActual--;
                break;
            case 2:
                if (usuarioActual < Usuarios.Count - 1)
                    usuarioActual++;
                break;
        }
    }

    public Usuario GetUsuario(int codigo)
    {
        Usuario u = null;
        int i = 0;
        bool encontrado = false;
        while (i < Usuarios.Count && !encontrado)
        {
            if (Usuarios[i].Codigo == codigo)
            {
                u = Usuarios[i];
                encontrado = true;
            }
            i++;
        }
        return u;
    }

    public void GuardarUsuarios(string ficheroUsuario)
    {
        try
        {
            StreamWriter sw = File.CreateText(ficheroUsuario);
            foreach (Usuario u in Usuarios)
            {
                sw.WriteLine(u.Codigo + ";" + u.Nombre + ";" + u.DNI + ";" 
                    + u.Telefono + ";" + u.Descuento);
            }
            sw.Close();
        }
        catch (PathTooLongException pe)
        {
            Console.WriteLine("Ruta del archivo demasiado larga: "
                + pe.Message);
        }
        catch (IOException ioe)
        {
            Console.WriteLine("Error de acceso al fichero: " + ioe.Message);
        }
        catch (Exception e)
        {
            Console.WriteLine("Error inesperado: " + e.Message);
        }
    }

    public void CargarUsuarios(string ficheroUsuarios)
    {
        if (File.Exists(ficheroUsuarios))
        {
            try
            {
                StreamReader sr = new StreamReader(ficheroUsuarios);
                string linea;
                while ((linea = sr.ReadLine()) != null)
                {
                    string[] datos = linea.Split(";");
                    int codigo = Convert.ToInt32(datos[0]);
                    string nombre = datos[1];
                    string DNI = datos[2];
                    int telefono = Convert.ToInt32(datos[3]);
                    byte descuento = Convert.ToByte(datos[4]);
                    AnyadirUsuario(new Usuario(codigo, nombre, DNI, telefono,
                        descuento));
                }
                sr.Close();
            }
            catch (PathTooLongException pe)
            {
                Console.WriteLine("Ruta del archivo demasiado larga: "
                    + pe.Message);
            }
            catch (IOException ioe)
            {
                Console.WriteLine("Error de acceso al fichero: " + ioe.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error inesperado: " + e.Message);
            }
        }
        else
            Console.WriteLine("El fichero de usuarios no existe");
    }    

    public int getUltimoCodigo()
    {
        int codigo = Usuarios[0].Codigo;
        foreach (Usuario u in Usuarios)
        {
            if (codigo < u.Codigo)
                codigo = u.Codigo;
        }
        codigo++;
        return codigo;
    }

    public int ObtenerCodigoUsuario(string nombre)
    {
        int i = 0;
        bool encontrado = false;
        int codigoUsuario = 0;
        while (i < Usuarios.Count && !encontrado)
        {
            if (Usuarios[i].Contiene(nombre))
            {
                codigoUsuario = Usuarios[i].Codigo;
                encontrado = true;
            }
            else
                i++;
        }
        if (!encontrado)
            return 0;
        else
            return codigoUsuario;
    }

    public int ObtenerUsuario(string nombre)
    {
        int i = 0;
        bool encontrado = false;
        int numUsuario=-1;
        while (i < Usuarios.Count && !encontrado)
        {
            if (Usuarios[i].Contiene(nombre))
            {
                numUsuario = i;
                encontrado = true;
            }
            else
                i++;
        }
        if (!encontrado)
            return 0;
        else
        return numUsuario;
    }
}