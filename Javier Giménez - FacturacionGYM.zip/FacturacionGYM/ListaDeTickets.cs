﻿using System;
using System.Collections.Generic;
using System.IO;

class ListaDeTickets
{
    public List<Ticket> Tickets { get; set; }

    public ListaDeTickets()
    {
        Tickets = new List<Ticket>();
    }

    public ListaDeTickets(List<Ticket> tickets)
    {
        Tickets = tickets;
    }

    public void AnyadirArticulo(Ticket t)
    {
        Tickets.Add(t);
    }

    public void BorrarTicket(ref int codigo)
    {        
        if (Tickets.Count > 0)
        {
            Tickets.RemoveAt(codigo);
            Tickets.Sort();
            codigo = 0;
        }
    }

    // devuelve el ticket anterior o siguiente o el mismo si no se puede obtener
    // opcion 1 -> anterior y opcion 2 -> siguiente
    public void ObtenerCodigoTicket(int codigo, int opcion)
    {
        switch (opcion)
        {
            case 1:
                if (codigo > 0)
                    codigo--;
                break;
            case 2:
                if (codigo < Tickets.Count - 1)
                    codigo++;
                break;
        }
    }

    // Formato en fichero:
    // codigo;dd/MM/yyyy;codigoUsuario;codigoArticulo;cantidad
    public void GuardarTickets(string ficheroTickets)
    {
        try
        {
            StreamWriter sw = File.CreateText(ficheroTickets);
            foreach (Ticket t in Tickets)
            {
                string textoSinArticulos = t.Codigo + ";" + t.FechaFormateada()
                    + ";" + t.CodigoUsuario + ";";
                foreach (KeyValuePair<int, int> articulo in t.Articulos)
                {
                    string texto = textoSinArticulos + articulo.Key + ";"
                        + articulo.Value;
                    sw.WriteLine(texto);
                }
            }
            sw.Close();
        }
        catch (PathTooLongException pe)
        {
            Console.WriteLine("Ruta del archivo demasiado larga: "
                + pe.Message);
        }
        catch (IOException ioe)
        {
            Console.WriteLine("Error de acceso al fichero: " + ioe.Message);
        }
        catch (Exception e)
        {
            Console.WriteLine("Error inesperado: " + e.Message);
        }
    }

    public void CargarTickets(string ficheroTickets)
    {
        if (File.Exists(ficheroTickets))
        {
            try
            {
                StreamReader sr = new StreamReader(ficheroTickets);
                string linea;
                while ((linea = sr.ReadLine()) != null)
                {
                    string[] datos = linea.Split(";");
                    int codigo = Convert.ToInt32(datos[0]);
                    DateTime fecha = ExtraerFecha(datos[1]);
                    int codigoUsuario = Convert.ToInt32(datos[2]);
                    int codigoArticulo = Convert.ToInt32(datos[3]);
                    int cantidad = Convert.ToInt32(datos[4]);
                    Dictionary<int, int> articulo = new Dictionary<int, int>();
                    articulo.Add(codigoArticulo, cantidad);

                    int posicion = -1;
                    if ((posicion = Contiene(codigo)) >= 0)
                    {
                        Tickets[posicion].Articulos.Add(codigoArticulo, cantidad);
                    }
                    else
                        Tickets.Add(new Ticket(codigo, fecha, codigoUsuario,
                            articulo));
                }
                sr.Close();
            }
            catch (PathTooLongException pe)
            {
                Console.WriteLine("Ruta del archivo demasiado larga: "
                    + pe.Message);
            }
            catch (IOException ioe)
            {
                Console.WriteLine("Error de acceso al fichero: " + ioe.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error inesperado: " + e.Message);
            }
        }
        else
            Console.WriteLine("El fichero de usuarios no existe");
    }

    public DateTime ExtraerFecha(string texto)
    {
        string[] partesFecha = texto.Split("/");
        int dia = Convert.ToInt32(partesFecha[0]);
        int mes = Convert.ToInt32(partesFecha[1]);
        int anyo = Convert.ToInt32(partesFecha[2]);
        DateTime fecha = new DateTime(anyo, mes, dia);

        return fecha;
    }

    public int getUltimoCodigo()
    {
        int codigo = Tickets[0].Codigo;
        foreach (Ticket t in Tickets)
        {
            if (codigo < t.Codigo)
                codigo = t.Codigo;
        }
        codigo++;
        return codigo;
    }

    public List<Ticket> ObtenerTodosLosTickets()
    {
        List<Ticket> tickets = new List<Ticket>();
        if (Tickets.Count > 0)
        {
            foreach (Ticket t in Tickets)
                tickets.Add(t);
        }
        return tickets;
    }


    public int ObtenerPosicionTicket(int codigo)
    {
        int posicion = -1;
        int i = 0;
        bool encontrado = false;
        while (i<Tickets.Count && !encontrado)
        {
            if (Tickets[i].Codigo == codigo)
            {
                encontrado = true;
                posicion = i;
            }
            else
                i++;
        }
        return posicion;
    }

    public List<Ticket> ObtenerTicketUsuario(int codigoUsuario)
    {
        List<Ticket> ticketsUsuario = new List<Ticket>();

        if (Tickets.Count > 0)
        {
            foreach(Ticket t in Tickets)
            {
                if (t.CodigoUsuario == codigoUsuario)
                    ticketsUsuario.Add(t);
            }
        }
        return ticketsUsuario;
    }

    public List<Ticket> ObtenerTicketsPorDia(byte dia)
    {
        List<Ticket> ticketsPorDia = new List<Ticket>();

        foreach (Ticket t in Tickets)
        {
            if (t.Fecha.Day == dia)
                ticketsPorDia.Add(t);
        }

        return ticketsPorDia;
    }

    public List<Ticket> ObtenerTicketsPorMes(byte mes)
    {
        List<Ticket> ticketsPorMes = new List<Ticket>();

        foreach(Ticket t in Tickets)
        {
            if (t.Fecha.Month == mes)
                ticketsPorMes.Add(t);
        }
        return ticketsPorMes;
    }

    public List<Ticket> ObtenerTicketsPorAnyo(int anyo)
    {
        List<Ticket> ticketsPorAnyo = new List<Ticket>();

        foreach (Ticket t in Tickets)
        {
            if (t.Fecha.Year == anyo)
                ticketsPorAnyo.Add(t);
        }
        return ticketsPorAnyo;
    }

    public int Contiene(int codigo)
    {
        bool encontrado = false;
        int i = 0;
        int posicion = -1;
        if (Tickets.Count > 0)
        {
            while (i < Tickets.Count && !encontrado)
            {
                if (Tickets[i].Codigo == codigo)
                {
                    encontrado = true;
                    posicion = i;
                }
                else
                    i++;
            }
        }
        return posicion;
    }
}