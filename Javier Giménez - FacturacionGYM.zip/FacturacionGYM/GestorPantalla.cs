﻿using System;
using System.Threading;
using System.Collections.Generic;

class GestorPantalla
{
    public ConsoleColor ColorFondoOriginal { get; set; }
    public ConsoleColor ColorTextoOriginal { get; set; }
    public ConsoleColor ColorFondo { get; set; }
    public ConsoleColor ColorTexto { get; set; }

    public const int MAX_USUARIOS_PANTALLA = 20;
    public const int MAX_ARTICULOS_PANTALLA = 20;
    public const int MAX_CODIGO = 10;
    public const int MAX_DETALLE = 50;
    public const int MAX_PRECIO = 10;
    public const int MAX_STOCK= 10;
    public const int SEGUNDOS_ESPERA = 3000;
    public const int MAX_TICKET = 10;
    public const int MAX_FECHA = 10;
    public const int MAX_COD_ARTICULO = 3;
    public const int MAX_CANTIDAD = 4;
    public const int MAX_DETALLE_REDUCIDO = 40;
    public const int MAX_IMPORTE = 10;
    public const int MAX_TOTAL = 10;


    public GestorPantalla()
    {
        ColorFondoOriginal = ConsoleColor.Cyan;
        ColorTextoOriginal = ConsoleColor.DarkBlue;
    }

    public void Escribir (int x, int y, string texto, ConsoleColor colorFondo,
        ConsoleColor colorTexto)
    {
        Console.SetCursorPosition(x, y);
        Console.BackgroundColor = colorFondo;
        Console.ForegroundColor = colorTexto;
        Console.Write(texto);
    }

    public void Escribir (int x, int y, string texto, ConsoleColor colorTexto)
    {
        Escribir(x, y, texto, ColorFondoOriginal, colorTexto);
    }

    public void Escribir(int x, int y, string texto)
    {
        Escribir(x, y, texto, ColorFondoOriginal, ColorTextoOriginal);
    }

    public void EscribirCentrado(int x, int y, int anchoCampo, string texto)
    {      
        Console.SetCursorPosition(x, y);
        int anchoTexto = texto.Length;
        int espacios = (anchoCampo - anchoTexto) / 2;
        string espaciosCampo = new string(' ', espacios);
        Console.Write(espaciosCampo + texto + espaciosCampo);
    }

    public void EscribirCentrado(int x, int y, int anchoCampo, string texto, 
        ConsoleColor colorFondo, ConsoleColor colorTexto)
    {
        Console.BackgroundColor = colorFondo;
        Console.ForegroundColor = colorTexto;
        Console.SetCursorPosition(x, y);
        int anchoTexto = texto.Length;
        int espacios = (anchoCampo - anchoTexto) / 2;
        string espaciosCampo = new string(' ', espacios);
        Console.Write(espaciosCampo + texto + espaciosCampo);
    }

    // Pedir un dato desde una posición con una longitud máxima que si se 
    // sobrepasa mostrará un texto de error en rojo durante 3 segundos y
    // volverá a pedir el dato
    public string Pedir (int x, int y, int longitudMax, string aviso, 
        ConsoleColor colorTexto)
    {
        bool datoCorrecto = false;
        //bool cancelado = false;
        int totalCaracteres = 0;
        string texto = "";
        bool textoDemasiadoLargo = false;

        Escribir(x, y, aviso, colorTexto);
        Console.SetCursorPosition(x+aviso.Length, y);
        Console.ForegroundColor = colorTexto;
        BorrarTexto(x+aviso.Length, y, longitudMax);
        ConsoleKeyInfo tecla;
        do
        {     
            if (textoDemasiadoLargo)
            {
                BorrarTexto(x + aviso.Length, y, longitudMax);
                texto = "";
                totalCaracteres = 0;
                textoDemasiadoLargo = false;
            }
            else if (Console.KeyAvailable)
            {                
                tecla = Console.ReadKey();   
                /*
                if (tecla.Key == ConsoleKey.Escape)
                {
                    totalCaracteres = 0;
                    texto = "";
                    cancelado = true;
                }
                else 
                */
                if (tecla.Key == ConsoleKey.Backspace)
                {
                    Console.Write(" ");
                    Console.SetCursorPosition(Console.CursorLeft - 1, y);
                    totalCaracteres--;
                    texto = texto.Substring(0, totalCaracteres);
                }
                else
                {
                    totalCaracteres++;

                    if (totalCaracteres < longitudMax - (x + aviso.Length))
                    {
                        if (tecla.Key == ConsoleKey.Enter)
                            datoCorrecto = true;
                        else
                            texto += tecla.KeyChar;
                    }
                    else
                    {
                        BorrarTexto(x + aviso.Length, y, longitudMax);
                        EscribirError(x+aviso.Length, y, 
                            "Texto demasiado largo", ConsoleColor.Black);
                        textoDemasiadoLargo = true;
                    }
                }
            }
        }
        while (!datoCorrecto);

        return texto;
    }

    // Función para dar formato a un mensaje de error y mostrarlo unos segundos
    public void EscribirError(int x, int y, string mensajeError, 
        ConsoleColor colorOriginal)
    {
        ConsoleColor colorTexto = ConsoleColor.DarkRed;
        Escribir(x, y, mensajeError, colorTexto);
        Thread.Sleep(SEGUNDOS_ESPERA);
        Console.ForegroundColor = colorOriginal;
    }

    // Función para pedir un dato para modificar
    public string Pedir(int x, int y, int longitudMax, string aviso, 
        ConsoleColor colorTexto, string valorAnterior)
    {
        string texto = Pedir(x, y, longitudMax, aviso, colorTexto);
        
        if (texto != "")
            valorAnterior = texto;

        return valorAnterior;
    }

    public void BorrarTexto(int x, int y, int tamanyo)
    {        
        int posicion = x;
        while (posicion < tamanyo)
        {
            Escribir(posicion, y, " ", ColorTexto);
            posicion++;
        }
        Console.SetCursorPosition(x, y);
    }

    public void BorrarDatosUsuario(int x, int y)
    {
        for (int i = 0; i < 6; i++)
        {
            for (int j = x; j < Console.WindowWidth; j++)
            {
                Escribir(j, y, " ");                
            }
            y++;
        }
    }

    public void BorrarDatosArticulos(int x, int y)
    {
        int filas = Console.WindowHeight - 1;
        int anchura = Console.WindowWidth;
        for (int i = y; i < filas; i++)
        {
            y = i;
            for (int j = 0; j < anchura; j++)
            {
                x = j;
                Console.SetCursorPosition(x, y);
                Console.Write(" ");
            }            
        }
    }

    public void MostrarUsuarios(int x, int y, ref int usuarioActual,
        ListaDeUsuarios lista)
    {
        if (lista.Usuarios.Count > 0)
        {
            lista.Usuarios.Sort();
            ColorTexto = ConsoleColor.Black;
            int usuariosAMostrar;
            if (lista.Usuarios.Count > MAX_USUARIOS_PANTALLA)
                usuariosAMostrar = MAX_USUARIOS_PANTALLA;
            else
                usuariosAMostrar = lista.Usuarios.Count;

            int usuarioInicial = 0;
            if (usuarioActual >= MAX_USUARIOS_PANTALLA)
            {
                usuarioInicial = usuarioActual - MAX_ARTICULOS_PANTALLA + 1;
            }
            for (int i = 0; i < usuariosAMostrar + usuarioInicial; i++)
            {
                usuarioActual = usuarioActual == -1 ? 0 : usuarioActual;
                ColorFondo = i == usuarioActual ? ConsoleColor.Gray : ColorFondoOriginal;

                Escribir(x, y, lista.Usuarios[i].Nombre, ColorFondo, ColorTexto);
                y++;
            }
        }
        else
            usuarioActual = -1;
    }

    public void MostrarUsuarioActual(int x, int y, int usuarioActual,
        ListaDeUsuarios lista)
    {
        if (usuarioActual >= 0)
        {
            Escribir(x, y, "" + lista.Usuarios[usuarioActual].Codigo, ColorTexto);
            Escribir(x, y + 1, "" + lista.Usuarios[usuarioActual].Nombre, ColorTexto);
            Escribir(x, y + 2, "" + lista.Usuarios[usuarioActual].DNI, ColorTexto);
            Escribir(x, y + 3, "" + lista.Usuarios[usuarioActual].Telefono, ColorTexto);
            Escribir(x, y + 4, "Dto: " + 
                lista.Usuarios[usuarioActual].Descuento + " %", ColorTexto);

        }
    }

    public void MostrarArticulosTicket(int x, int y, int xStock,
        ref int articuloActual, ListaDeArticulos lista)
    {
        Console.SetCursorPosition(x, y);
        int xOriginal = x;
        int articulosAMostrar=0;
        articuloActual = articuloActual == -1 ? 0 : articuloActual;

        if (lista.Articulos.Count > MAX_ARTICULOS_PANTALLA)
            articulosAMostrar = MAX_ARTICULOS_PANTALLA;
        else
            articulosAMostrar = lista.Articulos.Count;

        if (articulosAMostrar == 0)
            articuloActual = -1;
        else
        {
            lista.Articulos.Sort();
            ColorTexto = ConsoleColor.Black;
            for (int i = 0; i < articulosAMostrar; i++)
            {
                if (i == articuloActual)
                    ColorFondo = ConsoleColor.Gray;
                else
                    ColorFondo = ColorFondoOriginal;

                string stock = String.Format("{0,5}", lista.Articulos[i].Stock);
                Escribir(x, y, lista.Articulos[i].Detalle , ColorFondo, ColorTexto);
                Escribir(xStock, y, stock, ColorFondo, ColorTexto);
                y++;
            }            
        }
    }

    public int MostrarArticulos(int x, int y, ref int articuloActual,
        ListaDeArticulos lista)
    {
        int yArticuloActual = Console.CursorTop;
        Console.SetCursorPosition(0, y);
        for (int i = 0; i < Console.WindowWidth; i++)
            Console.Write(" ");

        int xOriginal = x;
        if (lista.Articulos.Count == 0)
            articuloActual = -1;

        if (lista.Articulos.Count > 0)
        {
            lista.Articulos.Sort();
            ColorFondo = ConsoleColor.DarkCyan;
            ColorTexto = ConsoleColor.Black;
            int articulosAMostrar;
            if (lista.Articulos.Count > MAX_ARTICULOS_PANTALLA)
                articulosAMostrar = MAX_ARTICULOS_PANTALLA;
            else
                articulosAMostrar = lista.Articulos.Count;

            EscribirCentrado(x, y, MAX_CODIGO, "Codigo");
            x += MAX_CODIGO;
            EscribirCentrado(x, y, MAX_DETALLE, "Detalle");
            x += MAX_DETALLE;
            EscribirCentrado(x, y, MAX_PRECIO, "Precio");
            x += MAX_PRECIO;
            EscribirCentrado(x, y, MAX_STOCK, "Stock");
            y += 4;
            x = xOriginal;

            articuloActual = articuloActual == -1 ? 0 : articuloActual;

            Console.ForegroundColor = ConsoleColor.Black;
            int articuloInicial = 0;
            if (articuloActual >= MAX_ARTICULOS_PANTALLA)
            {
                articuloInicial = articuloActual - MAX_ARTICULOS_PANTALLA + 1;
            }

            for (int i = articuloInicial; i < articulosAMostrar+articuloInicial; i++)
            {
                if (i == articuloActual)
                {
                    ColorFondo = ConsoleColor.Gray;
                    yArticuloActual = Console.CursorTop + 1;
                }
                else
                    ColorFondo = ColorFondoOriginal;

                EscribirCentrado(x, y, MAX_CODIGO, "" + lista.Articulos[i].Codigo,
                    ColorFondo, ColorTexto);
                x += MAX_CODIGO;
                Escribir(x, y, lista.Articulos[i].Detalle, ColorFondo, ColorTexto);
                x += MAX_DETALLE;

                string precio = String.Format("{0,7}",
                    lista.Articulos[i].Precio.ToString("0.00"));
                EscribirCentrado(x, y, MAX_PRECIO, "" + precio, ColorFondo, ColorTexto);
                x += MAX_PRECIO;

                string stock = String.Format("{0,5}", lista.Articulos[i].Stock);
                EscribirCentrado(x, y, MAX_STOCK, stock, ColorFondo, ColorTexto);
                x = xOriginal;
                y++;
            }
        }        
        return yArticuloActual;
    }

    public int PedirNuevoStock(int x, int y, int xMaxima, int stockAnterior)
    {
        int nuevoStock = stockAnterior;
        string stock = Pedir(x, y, xMaxima, "Nuevo Stock: ", 
            ConsoleColor.DarkRed, "" + stockAnterior);
        if (stock != "")
        {
            Int32.TryParse(stock, out nuevoStock);           
        }
        return nuevoStock;
    }

    public void MostrarArticuloActual(int x, int y, int articuloActual,
        ListaDeArticulos lista)
    {
        if (articuloActual >= 0)
        {
            Escribir(x, y, "" + lista.Articulos[articuloActual].Codigo, ColorTexto);
            Escribir(x, y + 1, "" + lista.Articulos[articuloActual].Detalle, ColorTexto);
            Escribir(x, y + 2, "" + lista.Articulos[articuloActual].Precio, ColorTexto);
            Escribir(x, y + 3, "" + lista.Articulos[articuloActual].Stock, ColorTexto);
        }
    }

    public void MostrarTicket(int x, int y, Ticket t, UsuarioGenerico u, 
       ListaDeArticulos articulosDelTicket)
    {
        int xOriginal = x;
        Escribir(x, y, "Ticket: " + t.Codigo, ConsoleColor.Black);
        x += MAX_TICKET;
        Escribir(x, y, "Fecha: " + t.FechaFormateada(), ConsoleColor.Black);
        x = xOriginal;
        y++;
        Escribir(x, y, u.Nombre, ConsoleColor.Black);
        y++;
        Escribir(x, y, "Artículos:", ConsoleColor.Black);
        y++;

        foreach (KeyValuePair<int, int> a in t.Articulos)
        {
            Articulo articulo = articulosDelTicket.ObtenerArticuloPorCodigo(a.Key);
            if (articulo != null)
            {
                string detalleArticulo = articulo.Detalle;
                Escribir(x, y, detalleArticulo + " (" + a.Value + ")",
                    ConsoleColor.Black);
                y++;
            }
        }        
    }

    public void MostrarArticulosCarrito(int x, int y, 
        Dictionary<int, int> carritoArticulos, ListaDeArticulos articulosOriginal,
        UsuarioGenerico usuario)
    {
        float total = 0;
        foreach (KeyValuePair<int, int> codArticulo in carritoArticulos)
        {
            int xOriginal = x;
            Articulo a = articulosOriginal.ObtenerArticuloPorCodigo(codArticulo.Key);
            x += MAX_CANTIDAD;
            Escribir(x, y, "" + codArticulo.Key, ConsoleColor.White, 
                ConsoleColor.DarkBlue);
            x += 2;
            string cantidad = String.Format("{0,5}", codArticulo.Value);
            Escribir(x, y, cantidad, ConsoleColor.White, ConsoleColor.DarkBlue);
            x += 8;
            Escribir(x, y, a.Detalle, ConsoleColor.White, ConsoleColor.DarkBlue);
            x += 30;
            string precio = String.Format("{0,7}", a.Precio);
            Escribir(x, y, precio, ConsoleColor.White, ConsoleColor.DarkBlue);

            float importeTotal = codArticulo.Value * a.Precio;            
            if (usuario is Usuario)
            {
                int descuento = ((Usuario)usuario).Descuento;
                if (descuento > 0)
                {
                    importeTotal *= 1 - (descuento/100.0f);
                }
            }
            
            total += importeTotal;
            string importe = String.Format("{0,7}", 
                importeTotal.ToString("0.00"));
            x += 9;
            Escribir(x, y, importe, ConsoleColor.White, ConsoleColor.DarkBlue);                  

            x = xOriginal;
            y++;                
        }
        x = 58;
        y = Console.WindowHeight - 5;
        string totalPedido = String.Format("{0,7}", total.ToString("0.00"));
        EscribirCentrado(x, y, MAX_TOTAL, totalPedido, ConsoleColor.White, 
            ConsoleColor.DarkRed);
    }

    public void BorrarArticulosTicket(int x, int y, int xMaxima, int yMaxima)
    {
        int xOriginal = x;
        Console.SetCursorPosition(x, y);
        while (y < yMaxima)
        {
            while(x < xMaxima)
            {
                Escribir(x, y, " ", ConsoleColor.Cyan, ConsoleColor.Black);
                x++;
            }
            x = xOriginal;
            y++;
        }        
    }

    public void MostrarExportar()
    {
        Escribir(40, 4, "EXPORTAR (0)", ConsoleColor.Gray, ConsoleColor.DarkBlue);
    }

    public void EscribirExportacionCorrecta()
    {
        ConsoleColor colorTexto = ConsoleColor.DarkBlue;
        Escribir(55, 4, "Exportación correcta", colorTexto);
        Thread.Sleep(SEGUNDOS_ESPERA);
        Console.ForegroundColor = ConsoleColor.Black;
    }
}