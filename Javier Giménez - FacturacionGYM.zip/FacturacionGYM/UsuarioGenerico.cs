﻿// clase para un usuario genérico del que heredarán los clientes (clase Usuario)
class UsuarioGenerico
{
    public int Codigo { get; set;  }
    public string Nombre { get; set; }

    public UsuarioGenerico(string nombre)
    {
        Codigo = 0;
        Nombre = nombre;
    }

    override public string ToString()
    {
        return Nombre + " (Cod " + Codigo + ")";
    }
}