﻿using System;

class Usuario : UsuarioGenerico, IComparable<Usuario>
{
    public string DNI { get; set; }
    public int Telefono { get; set; }
    public byte Descuento { get; set; }


    public Usuario(int codigo, string nombre, string DNI, int telefono)
        :this(codigo, nombre, DNI, telefono, 0)
    {
    }

    public Usuario(int codigo, string nombre, string DNI, int telefono,
        byte descuento)
        : base(nombre)
    {
        Codigo = codigo;
        this.DNI = DNI;
        Telefono = telefono;
        Descuento = descuento;
    }

    public override string ToString()
    {
        return base.ToString() + " - " + DNI + "    Teléfono: " + Telefono;
    }
    public bool Contiene(string texto)
    {
        int codigoABuscar;
        bool contiene = DNI==texto || Nombre.ToLower().Contains(texto.ToLower());
        if (Int32.TryParse(texto, out codigoABuscar))
        {
            if (codigoABuscar == Codigo)
                contiene = true;
        }
        
        return contiene;
    }

    public int CompareTo(Usuario otro)
    {
        return String.Compare(Nombre, otro.Nombre, true);
    }
}