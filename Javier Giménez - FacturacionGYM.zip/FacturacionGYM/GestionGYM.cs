﻿// clase para la gestión principal

using System;

class GestionGYM
{
    private const string NOMBRE_GIMNASIO = "Gimnasio GYM";
    private static string[] opcionesPrincipales = {"Usuarios", "Artículos",
        "Tickets", "Terminar"};

    private static int usuarioActual = -1;
    private static int articuloActual = -1;
    private static int ticketActual = -1;

    private static GestorPantalla gestorPantalla = new GestorPantalla();
    private static GestorDeUsuarios gestorUsuarios = new GestorDeUsuarios();
    private static GestorDeArticulos gestorArticulos = new GestorDeArticulos();
    private static GestorDeTickets gestorTickets = new GestorDeTickets();

    const int XLISTADO = 5;
    const int YLISTADO = 2;
    const int XDATO = 50;
    const int YDATO = 2;
    const int XMAXINA = 110;

    public void Lanzar()
    {
        Inicializar();
        LanzarPantallaPrincipal();          
    }

    public static void LanzarPantallaPrincipal()
    {
        bool salir;
        MostrarBienvenida();
        do
        {
            byte opcion = RecogerOpcion();
            salir = EjecutarOpcion(opcion);
        }
        while (!salir);
        Console.ResetColor();
    }

    public void Inicializar()
    {
        gestorUsuarios.InicializarUsuarios();
        gestorArticulos.InicializarArticulos();
        gestorTickets.InicializarTickets();
    }

    private static bool EjecutarOpcion(byte opcion)
    {
        bool salir = false;

        switch (opcion)
        {
            case 1: gestorUsuarios.MostrarPantallaUsuarios(usuarioActual); break;
            case 2: gestorArticulos.MostrarPantallaArticulos(articuloActual); break;
            case 3: 
                gestorTickets.MostrarPantallaTickets(ref ticketActual, null,
                    gestorUsuarios.GetListaDeUsuarios(), 
                    gestorArticulos.GetListaDeArticulos()); 
                break;
            case 4: salir = Salir(); break;                    
        }
        return salir;
    }

    public static void MostrarCabecera()
    {
        int x = 5;
        int y = 0;

        gestorPantalla.Escribir(x, y, NOMBRE_GIMNASIO);
        gestorPantalla.Escribir(50, y, DateTime.Now.ToString("dd/MM/yyyy"));
    }

    public static void MostrarMenu(string[] opciones)
    {
        int y = Console.WindowHeight - 1;

        Console.SetCursorPosition(0, y);
        Console.BackgroundColor = ConsoleColor.DarkCyan;
        Console.ForegroundColor = ConsoleColor.Yellow;
        for (int i = 0; i < 5; i++)
        {
            Console.Write(" ");
        }
        for (int i = 0; i < opciones.Length; i++)
        {
            Console.Write((i + 1) + "-" + opciones[i] + "    ");
        }
        for (int i = Console.CursorLeft; i < Console.WindowWidth; i++)
            Console.Write(" ");

        Console.SetCursorPosition(1, 1);
    }

    public static void MostrarBienvenida()
    {     
        Console.BackgroundColor = gestorPantalla.ColorFondoOriginal;
        Console.ForegroundColor = gestorPantalla.ColorTextoOriginal;
        Console.Clear();
        Console.CursorVisible = false;
        MostrarCabecera();
        MostrarMenu(opcionesPrincipales);
    }   

    private static byte RecogerOpcion()
    {
        byte opcion = 0;
        ConsoleKeyInfo tecla;
 
        if (Console.KeyAvailable)
        {
            tecla = Console.ReadKey(true);
            if (tecla.KeyChar >= '1' && tecla.KeyChar <= '4')
                opcion = (byte)(tecla.KeyChar - '0');
        }
        return opcion;
    }

    private static bool Salir()
    {
        return true;
    }
   
}