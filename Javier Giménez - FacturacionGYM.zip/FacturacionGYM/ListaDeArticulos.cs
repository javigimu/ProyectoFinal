﻿using System;
using System.Collections.Generic;
using System.IO;

class ListaDeArticulos
{
    public List<Articulo> Articulos { get; set; }

    public ListaDeArticulos()
    {
        Articulos = new List<Articulo>();
    }

    public ListaDeArticulos(List<Articulo> articulos)
    {
        Articulos = articulos;
    }

    public void AnyadirArticulo(Articulo a)
    {
        Articulos.Add(a);
    }

    public void BorrarArticulo(ref int articuloActual)
    {
        Articulos.Remove(Articulos[articuloActual]);
        articuloActual = 0;
    }

    public void Modificar(int articuloActual, string detalle, float precio,
        int stock)
    {
        Articulos[articuloActual].Detalle = detalle;
        Articulos[articuloActual].Precio = precio;
        Articulos[articuloActual].Stock = stock;
    }

    // devuelve el artículo anterior o siguiente o el mismo si no se puede obtener
    // opcion 1 -> anterior y opcion 2 -> siguiente
    public void ObtenerCodigoArticulo(ref int articuloActual, int opcion)
    {
        switch (opcion)
        {
            case 1:
                if (articuloActual > 0)
                    articuloActual--;
                break;
            case 2:
                if (articuloActual < Articulos.Count - 1)
                    articuloActual++;
                break;
        }
    }

    public void GuardarArticulos(string ficheroArticulos)
    {
        try
        {
            StreamWriter sw = File.CreateText(ficheroArticulos);
            foreach (Articulo a in Articulos)
            {
                string texto = a.Codigo + ";" + a.Detalle + ";" + a.Precio + ";"
                    + a.Stock;
                if (a is Actividad)
                    texto += ";" + "a";
                sw.WriteLine(texto);                
            }
            sw.Close();
        }
        catch (PathTooLongException pe)
        {
            Console.WriteLine("Ruta del archivo demasiado larga: "
                + pe.Message);
        }
        catch (IOException ioe)
        {
            Console.WriteLine("Error de acceso al fichero: " + ioe.Message);
        }
        catch (Exception e)
        {
            Console.WriteLine("Error inesperado: " + e.Message);
        }
    }

    public void CargarArticulos(string ficheroArticulos)
    {
        if (File.Exists(ficheroArticulos))
        {
            try
            {
                StreamReader sr = new StreamReader(ficheroArticulos);
                string linea;
                while ((linea = sr.ReadLine()) != null)
                {
                    string[] datos = linea.Split(";");
                    int codigo = Convert.ToInt32(datos[0]);
                    string detalle = datos[1];
                    float precio = Convert.ToSingle(datos[2]);
                    int stock = Convert.ToInt32(datos[3]);

                    if (datos.Length == 5)
                        AnyadirArticulo(new Actividad(codigo, detalle, precio));
                    else
                        AnyadirArticulo(new Articulo(codigo, detalle, precio, 
                            stock));
                }
                sr.Close();
            }
            catch (PathTooLongException pe)
            {
                Console.WriteLine("Ruta del archivo demasiado larga: "
                    + pe.Message);
            }
            catch (IOException ioe)
            {
                Console.WriteLine("Error de acceso al fichero: " + ioe.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error inesperado: " + e.Message);
            }
        }
        else
            Console.WriteLine("El fichero de usuarios no existe");
    }

    public int getUltimoCodigo()
    {
        int codigo = Articulos[0].Codigo;
        foreach (Articulo a in Articulos)
        {
            if (codigo < a.Codigo)
                codigo = a.Codigo;
        }
        codigo++;
        return codigo;
    }

    public int ObtenerArticulo(string texto)
    {
        int i = 0;
        bool encontrado = false;
        int numArticulo = -1;
        while (i < Articulos.Count && !encontrado)
        {
            if (Articulos[i].Contiene(texto))
            {
                numArticulo = i;
                encontrado = true;
            }
            i++;
        }
        return numArticulo;
    }

    public List<Articulo> ObtenerArticulosPorCodigo(int codigo)
    {
        List<Articulo> articulos = new List<Articulo>();
        if (Articulos.Count > 0)
        {
            foreach (Articulo a in Articulos)
            {
                if (a.Codigo == codigo)
                    articulos.Add(a);
            }
        }
        return articulos;
    }

    public Articulo ObtenerArticuloPorCodigo(int codigo)
    {
        Articulo articuloEncontrado =null;
        int i = 0;
        bool encontrado = false;

        while (i<Articulos.Count && !encontrado)
        {
            if (Articulos[i].Codigo == codigo)
            {
                encontrado = true;
                articuloEncontrado = Articulos[i];
            }
            else
                i++;
        }
        
        return articuloEncontrado;
    }

    public List<Articulo> MostrarAgotados()
    {
        List<Articulo> agotados = new List<Articulo>();
        foreach(Articulo a in Articulos)
        {
            if (a.Stock == 0)
            {
                agotados.Add(a);                
            }
        }
        return agotados;
    }

    public int Buscar(string texto)
    {
        int numArticulo = -1;
        int i = 0;
        bool encontrado = false;
        while (i < Articulos.Count && !encontrado)
        {
            if (Articulos[i].Detalle.ToLower().Contains(texto))
                encontrado = true;
            else
                i++;
        }
        if (encontrado)
            numArticulo = i;

        return numArticulo;
    }
}