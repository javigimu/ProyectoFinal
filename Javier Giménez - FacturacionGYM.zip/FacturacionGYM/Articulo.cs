﻿using System;

class Articulo : IComparable<Articulo>
{
    public int Codigo { get; set; }
    public string Detalle { get; set; }
    public float Precio { get; set; }
    public int Stock { get; set; }

    public Articulo (int codigo, string detalle, float precio, int stock)
    {
        Codigo = codigo;
        Detalle = detalle;
        Precio = precio;
        Stock = stock;
    }

    public override string ToString()
    {
        return Codigo + ": " + Detalle + " (" + Precio + " €) => " + Stock + 
            " uds";
    }

    public int CompareTo(Articulo otro)
    {
        int comparacion = String.Compare(Detalle, otro.Detalle, true);
        if (comparacion == 0)
            comparacion = Precio.CompareTo(otro.Precio);

        return comparacion;
    }

    public bool Contiene(string texto)
    {
        return Detalle.Contains(texto);
    }
}