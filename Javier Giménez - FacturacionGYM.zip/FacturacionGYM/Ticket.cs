﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

class Ticket : IComparable<Ticket>
{
    public int Codigo { get; set; }
    public DateTime Fecha { get; }
    public int CodigoUsuario { get; set; }
    public Dictionary<int, int> Articulos { get; set; }    

    public Ticket (int codigo, DateTime fecha, int codigoUsuario, 
        Dictionary<int, int> articulos)
    {
        Codigo = codigo;
        Fecha = fecha;
        CodigoUsuario = codigoUsuario;
        Articulos = articulos;
    }

    public int CompareTo(Ticket otro)
    {
        return -1 * Fecha.CompareTo(otro.Fecha);
    }

    public string FechaFormateada()
    {
        return Fecha.ToString("dd/MM/yyyy");
    }

    public ListaDeArticulos ObtenerListaDeArticulos(ListaDeArticulos articulos)
    {
        ListaDeArticulos listaArticulos = new ListaDeArticulos();
        foreach (KeyValuePair<int, int> articulo in Articulos)
        {
            Articulo a = articulos.ObtenerArticuloPorCodigo(articulo.Key);
            if (a!=null)
                listaArticulos.AnyadirArticulo(a);
        }

        return listaArticulos;
    }
}
