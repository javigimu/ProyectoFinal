﻿using System;
using System.Collections.Generic;

class GestorDeTickets
{
    private const string FICHERO_TICKETS = "datos/tickets.txt";

    private ListaDeTickets tickets = new ListaDeTickets();
    private UsuarioGenerico invitado = new UsuarioGenerico("Invitado");

    private string[] opcionesTicket = {"Añadir", "Ver Tickets",
        "Exportar tickets", "Borrar", "Menu principal"};
    private GestorPantalla gp = new GestorPantalla();

    const int XDATO = 4;
    const int YDATO = 4;
    const int XMAXIMA = 110;
    const int XARTICULOS = 70;
    const int XMAX_ARTICULOS = 40;
    const int XTICKET = 8;
    const int XFECHA = 12;
    const int XCOBRAR = 15;
    const int XDESCUENTO = 15;
    const int XSTOCK = 5;
    const int XPRECIO = 9;
    const int XCAMPOtOTAL = 57;
    const int YARTICULOS_CARRITO = 8;


    // Estructura del fichero de usuarios: codigo;detalle;precio;stock
    public void InicializarTickets()
    {
        tickets.CargarTickets(FICHERO_TICKETS);
    }

    public void MostrarPantallaTicketsVacia()
    {
        Console.BackgroundColor = gp.ColorFondoOriginal;
        Console.ForegroundColor = gp.ColorTextoOriginal;
        Console.Clear();
        GestionGYM.MostrarCabecera();
        GestionGYM.MostrarMenu(opcionesTicket);
    }

    public void MostrarPantallaTickets(ref int ticketActual, 
        ListaDeTickets listaTickets, ListaDeUsuarios usuarios,
        ListaDeArticulos articulos)
    {
        MostrarPantallaTicketsVacia();
        if (listaTickets == null)
            listaTickets = tickets;

        if (listaTickets.Tickets.Count > 0)
        {
            listaTickets.Tickets.Sort();
            gp.ColorTexto = ConsoleColor.Black;

            if (ticketActual == -1)
                ticketActual = 0;

            int codigoUsuario = listaTickets.Tickets[ticketActual].CodigoUsuario;
            UsuarioGenerico usuario;
            if (codigoUsuario == 0)
                usuario = invitado;
            else                                
                usuario = usuarios.GetUsuario(codigoUsuario);

            ListaDeArticulos articulosDelTicket 
                = listaTickets.Tickets[ticketActual].ObtenerListaDeArticulos(articulos);
            
            gp.MostrarTicket(XDATO, YDATO, listaTickets.Tickets[ticketActual], 
                usuario, articulosDelTicket);

            bool volverAlMenuPrincipal;
            do
            {
                byte opcion = RecogerOpcionTicket(ref ticketActual, 
                    usuarios, articulos, listaTickets);
                volverAlMenuPrincipal = EjecutarOpcionTicket(opcion, 
                    ticketActual, usuarios, articulos);
            }
            while (!volverAlMenuPrincipal);
            GestionGYM.LanzarPantallaPrincipal();
            //GestionGYM.MostrarBienvenida();
        }       
    }

    public bool EjecutarOpcionTicket(byte opcion, int ticketActual,
        ListaDeUsuarios usuarios, ListaDeArticulos articulos)
    {
        bool volverAlMenuPrincipal = false;

        switch (opcion)
        {
            case 1: AnyadirTicket(ref ticketActual, usuarios, articulos); break;
            case 2: VerTicketsPorFecha(ref ticketActual, usuarios, articulos); break;
            case 3: Exportar(usuarios, articulos); break;
            case 4: BorrarTicket(ref ticketActual, usuarios, articulos); break;
            case 5: volverAlMenuPrincipal = true; break;
        }
        return volverAlMenuPrincipal;
    }

    public void Exportar(ListaDeUsuarios usuarios, ListaDeArticulos articulos)
    {
        ExportadorDeArchivos exportar = new ExportadorDeArchivos();
        //exportar.ExportarAPdf(tickets, usuarios, articulos);
    }

    public void VerTicketsPorFecha(ref int ticketActual, ListaDeUsuarios usuarios,
        ListaDeArticulos articulos)
    {
        MostrarPantallaTicketsVacia();     
        string fechaTexto = gp.Pedir(XDATO, YDATO, XMAXIMA, 
            "Introduce el año o Intro para continuar: ", ConsoleColor.Black);
        ListaDeTickets ticketsFiltrados = new ListaDeTickets();
        if (fechaTexto != "")
        {             
            ticketsFiltrados.Tickets = tickets.ObtenerTicketsPorAnyo(
                Convert.ToInt32(fechaTexto));
        }
        else
        {
            gp.BorrarTexto(XDATO, YDATO, XMAXIMA);
            fechaTexto = gp.Pedir(XDATO, YDATO, XMAXIMA,
            "Introduce el mes o Intro para continuar: ", ConsoleColor.Black);
            if (fechaTexto != "")
            {
                ticketsFiltrados.Tickets = tickets.ObtenerTicketsPorMes(
                    Convert.ToByte(fechaTexto));
            }            
            else
            {
                gp.BorrarTexto(XDATO, YDATO, XMAXIMA);
                MostrarPantallaTickets(ref ticketActual, tickets, usuarios,
                    articulos);
            }
        }

        if (ticketsFiltrados.Tickets.Count > 0)
        {
            ticketActual = 0;
            ticketsFiltrados.Tickets.Sort();
            MostrarPantallaTickets(ref ticketActual, ticketsFiltrados, usuarios, 
                articulos);
        }
        else
        {
            gp.BorrarTexto(XDATO, YDATO, XMAXIMA);
            gp.EscribirError(XDATO, YDATO, "No se han encontrado tickets",
                ConsoleColor.Black);
        }
    }

    public void BorrarTicket(ref int ticketActual, ListaDeUsuarios usuarios,
        ListaDeArticulos articulos)
    {
        gp.EscribirError(50, YDATO, "Se va a borrar el ticket, pulse (s/n) " +
            "para confirmar", ConsoleColor.Black);
        ConsoleKeyInfo tecla;
        do
        {
            if (Console.KeyAvailable)
            {
                tecla = Console.ReadKey();
                if (tecla.KeyChar == 's')
                {
                    tickets.BorrarTicket(ref ticketActual);
                    tickets.GuardarTickets(FICHERO_TICKETS);
                    ticketActual = 0;
                }
                else
                {
                    MostrarPantallaTicketsVacia();
                    gp.EscribirError(50, YDATO, "Borrado de ticket cancelado",
                        ConsoleColor.Black);
                }
                MostrarPantallaTickets(ref ticketActual, tickets, usuarios,
                       articulos);
            }
        }
        while (!Console.KeyAvailable);
    }

    public void AnyadirTicket(ref int ticketActual, ListaDeUsuarios usuarios, 
        ListaDeArticulos articulos)
    {
        MostrarPantallaTicketsVacia();

        int codigoUsuario = PedirUsuario(usuarios);
        UsuarioGenerico usuario;
        if (codigoUsuario > 0)
            usuario = usuarios.GetUsuario(codigoUsuario);
        else
            usuario = invitado;        

        gp.BorrarTexto(XDATO, YDATO, XMAXIMA);

        int articuloActual = 0;      
        int codigo = tickets.getUltimoCodigo();
        DateTime fecha = DateTime.Now;

        MostrarCamposNuevoTicket(codigo, usuario, articuloActual, articulos);
        Dictionary<int, int> carritoArticulos = new Dictionary<int, int>();
        bool cobrar = false;

        bool filtrado = false;
        bool cancelado = false;
        ListaDeArticulos articulosOriginal = articulos;
        do
        {
            if (!filtrado)
                articulos = articulosOriginal;

            cobrar = RecogerOpcionNuevoTicket(ref articuloActual, 
                ref articulos, carritoArticulos, usuario, ref filtrado, 
                articulosOriginal, ref cancelado);
        }
        while (!cobrar && !cancelado);
        
        if (cobrar)
        {
            Ticket nuevoTicket = new Ticket(codigo, fecha, codigoUsuario,
                carritoArticulos);
            tickets.Tickets.Add(nuevoTicket);
            tickets.Tickets.Sort();
            ticketActual = tickets.ObtenerPosicionTicket(codigo);
            tickets.GuardarTickets(FICHERO_TICKETS);
            MostrarPantallaTickets(ref ticketActual, tickets, usuarios, 
                articulos);
        } 
        else if (cancelado)
        {
            MostrarPantallaTicketsVacia();
            gp.EscribirError(50, 12, "Nuevo ticket cancelado", ConsoleColor.Black);
            MostrarPantallaTickets(ref ticketActual, tickets, usuarios,
                articulos);
        }
    }

    private bool RecogerOpcionNuevoTicket(ref int articuloActual, 
        ref ListaDeArticulos articulos, Dictionary<int, int> carritoArticulos,
        UsuarioGenerico usuario, ref bool filtrado, 
        ListaDeArticulos articulosOriginal, ref bool cancelado)
    {
        bool cobrar = false; 

        ConsoleKeyInfo tecla;
        if (Console.KeyAvailable)
        {
            tecla = Console.ReadKey(true);
            if (tecla.Key == ConsoleKey.Escape)
            {
                carritoArticulos.Clear();
                cancelado = true;                                
            }
            if (tecla.Key == ConsoleKey.F10)
            {
                cobrar = true;
            }
            else if (tecla.Key == ConsoleKey.F5)
            {
                filtrado = !filtrado;
                if (filtrado)
                {
                    gp.BorrarTexto(XARTICULOS + 12, YDATO - 2, XMAXIMA);
                    gp.EscribirCentrado(XARTICULOS + 12, YDATO - 2, 30, " ",
                        ConsoleColor.White, ConsoleColor.DarkBlue);
                    Console.SetCursorPosition(XARTICULOS + 12, YDATO - 2);
                    int x = XARTICULOS + 12;

                    string textoBusqueda = "";
                    do
                    {
                        if (Console.KeyAvailable)
                        {
                            tecla = Console.ReadKey(); 
                            if (tecla.Key != ConsoleKey.Enter)
                            {
                                textoBusqueda += tecla.KeyChar;
                                GestorDeArticulos gestorArticulos =
                                    new GestorDeArticulos();
                                gestorArticulos.SetListaDeArticulos(articulos);
                                articulos =
                                    gestorArticulos.ObtenerArticulosPorDetalle
                                    (textoBusqueda);

                                gp.BorrarArticulosTicket(XARTICULOS, YDATO + 2,
                                    Console.WindowWidth, Console.WindowHeight - 5);
                                gp.MostrarArticulosTicket(XARTICULOS, YDATO + 2,
                                    XARTICULOS + XMAX_ARTICULOS,
                                    ref articuloActual, articulos);
                                x++;
                                Console.SetCursorPosition(x, YDATO - 2);
                                Console.BackgroundColor = ConsoleColor.White;
                                Console.ForegroundColor = ConsoleColor.DarkBlue;
                                articuloActual = 0;
                            }
                        }
                    }
                    while (tecla.Key != ConsoleKey.Enter);

                    gp.BorrarTexto(XARTICULOS, YDATO + 1, Console.WindowWidth);
                    gp.Escribir(XARTICULOS + 12, YDATO - 2, "Cancelar filtrado (F5)",
                        ConsoleColor.White, ConsoleColor.DarkBlue);
                }
                else
                {
                    gp.BorrarTexto(XARTICULOS, YDATO + 1, Console.WindowWidth);
                    gp.Escribir(XARTICULOS + 12, YDATO - 2, "Filtrar articulos (F5)",
                        ConsoleColor.White, ConsoleColor.DarkBlue);
                    gp.BorrarArticulosTicket(XARTICULOS, YDATO + 2,
                            Console.WindowWidth, Console.WindowHeight - 5);
                    gp.MostrarArticulosTicket(XARTICULOS, YDATO + 2,
                        XARTICULOS + XMAX_ARTICULOS, ref articuloActual, 
                        articulosOriginal);
                }     
            }
            else if (tecla.KeyChar == '+')
            {
                Articulo a = articulos.Articulos[articuloActual];
                int codigo = a.Codigo;
                int stock = a.Stock;                
                int cantidad = 1;

                if (carritoArticulos.ContainsKey(codigo))
                {
                    if (stock > 0)
                    {
                        carritoArticulos[codigo]++;
                        a.Stock--;
                    }
                }
                else
                {
                    if (stock > 0)
                        a.Stock--;
                    carritoArticulos.Add(codigo, cantidad);
                }

                gp.MostrarArticulosCarrito(XDATO, YARTICULOS_CARRITO, 
                    carritoArticulos, articulosOriginal, usuario);
                gp.MostrarArticulosTicket(XARTICULOS, YDATO + 2,
                        XARTICULOS + XMAX_ARTICULOS, ref articuloActual,
                        articulosOriginal);
            }
            else if (tecla.KeyChar == '-')
            {
                Articulo a = articulos.Articulos[articuloActual];
                int codigo = a.Codigo;

                if (carritoArticulos.ContainsKey(codigo))
                {
                    if (a is Actividad)
                    {
                        carritoArticulos.Remove(codigo);
                        MostrarPantallaTicketsVacia();
                        MostrarCamposNuevoTicket(codigo, usuario,
                            articuloActual, articulos);
                    }
                    else
                    {
                        int cantidad = carritoArticulos[codigo];
                        if (cantidad > 0)
                        {
                            carritoArticulos[codigo]--;
                            cantidad--;
                            a.Stock++;
                            if (cantidad == 0)
                            {
                                carritoArticulos.Remove(codigo);
                                MostrarPantallaTicketsVacia();
                                MostrarCamposNuevoTicket(codigo, usuario,
                                    articuloActual, articulos);
                            }
                        }
                    }
                }
                
                gp.MostrarArticulosCarrito(XDATO, YARTICULOS_CARRITO,
                    carritoArticulos, articulosOriginal, usuario);
                gp.MostrarArticulosTicket(XARTICULOS, YDATO + 2,
                        XARTICULOS + XMAX_ARTICULOS, ref articuloActual,
                        articulosOriginal);
            }
            else if (tecla.Key == ConsoleKey.DownArrow)
            {
                if (articuloActual < articulos.Articulos.Count - 1)
                {
                    articuloActual++;
                    gp.MostrarArticulosTicket(XARTICULOS, YDATO + 2, 
                        XARTICULOS + XMAX_ARTICULOS, ref articuloActual, 
                        articulos);
                }
            }
            else if (tecla.Key == ConsoleKey.UpArrow)
            {
                if (articuloActual > 0)
                {
                    articuloActual--;
                    gp.MostrarArticulosTicket(XARTICULOS, YDATO + 2,
                        XARTICULOS + XMAX_ARTICULOS, ref articuloActual,
                        articulos);
                }
            }
        }
        return cobrar;
    }

    public void MostrarCamposNuevoTicket(int codigo, UsuarioGenerico usuario, 
        int articuloActual, ListaDeArticulos articulos)
    {
        gp.EscribirCentrado(XDATO, YDATO, XTICKET, "Ticket",
            ConsoleColor.Cyan, ConsoleColor.Black);
        gp.EscribirCentrado(XDATO, YDATO + 1, XTICKET, "" + codigo,
            ConsoleColor.White, ConsoleColor.Gray);
        gp.EscribirCentrado(XDATO + XTICKET+2, YDATO, XFECHA, "Fecha",
            ConsoleColor.Cyan, ConsoleColor.Black);
        gp.EscribirCentrado(XDATO + XTICKET, YDATO + 1, XFECHA,
            FechaFormateada(DateTime.Now), ConsoleColor.White,
            ConsoleColor.Gray);

        int yPie = Console.WindowHeight - 5;
        gp.Escribir(XARTICULOS - 20, yPie, "TOTAL: ", ConsoleColor.Gray,
               ConsoleColor.Black);
        gp.Escribir(XCAMPOtOTAL, yPie, "          ",
            ConsoleColor.White, ConsoleColor.Black);        
        if (usuario is Usuario)
        {
            gp.EscribirCentrado(XDATO + XTICKET + XFECHA, YDATO, XDESCUENTO,
                "Dto (%)", ConsoleColor.Cyan, ConsoleColor.Black);
            gp.EscribirCentrado(XDATO + XTICKET + XFECHA, YDATO + 1,
                XDESCUENTO, "" + ((Usuario)usuario).Descuento, ConsoleColor.Gray,
                ConsoleColor.White);            
            gp.Escribir(XDATO, yPie, ((Usuario)usuario).Nombre, 
                ConsoleColor.DarkGray);
            gp.Escribir(XDATO, yPie+1, ((Usuario)usuario).DNI, 
                ConsoleColor.DarkGray);
            gp.Escribir(XDATO, yPie+2, ""+ ((Usuario)usuario).Telefono,
                ConsoleColor.DarkGray);       
        }

        gp.EscribirCentrado(XCAMPOtOTAL- 17, YDATO, XCOBRAR, "COBRAR (F10)",
            ConsoleColor.Gray, ConsoleColor.DarkMagenta);

        gp.Escribir(XARTICULOS, YDATO - 2, "(+ / -)",
            ConsoleColor.White, ConsoleColor.DarkBlue);
        gp.Escribir(XARTICULOS + 12, YDATO - 2, "Filtrar Articulos (F5)",
            ConsoleColor.White, ConsoleColor.DarkBlue);
        gp.Escribir(XARTICULOS, YDATO, "Detalle", ConsoleColor.DarkBlue,
            ConsoleColor.White);
        gp.Escribir(XARTICULOS + XMAX_ARTICULOS, YDATO , "Stock",
            ConsoleColor.DarkBlue, ConsoleColor.White);
        gp.MostrarArticulosTicket(XARTICULOS, YDATO+2, XARTICULOS + XMAX_ARTICULOS,
            ref articuloActual, articulos);
        for (int i = YDATO +3; i<yPie-1; i++)
        {
            gp.EscribirCentrado(XDATO, i, XARTICULOS - 7, " ", 
                ConsoleColor.White, ConsoleColor.Black);         
        }
        MostrarMenuArticulosCarrito();            
    }

    public void MostrarMenuArticulosCarrito()
    {
        gp.EscribirCentrado(XDATO, YDATO + 3, XTICKET, "Cod", ConsoleColor.Gray,
            ConsoleColor.Black);
        gp.EscribirCentrado(XDATO + XTICKET-1, YDATO + 3, XSTOCK, "Cant",
            ConsoleColor.Gray, ConsoleColor.Black);
        gp.EscribirCentrado(XDATO + XTICKET-2 + XSTOCK, YDATO + 3,
            XMAX_ARTICULOS-5, "Detalle", ConsoleColor.Gray, ConsoleColor.Black);
        gp.EscribirCentrado(XDATO + XTICKET + XSTOCK + XMAX_ARTICULOS-7, 
            YDATO + 3, XPRECIO, "Precio", ConsoleColor.Gray, 
            ConsoleColor.Black);
        gp.EscribirCentrado(XARTICULOS-12,YDATO + 3, XPRECIO, "Importe", 
            ConsoleColor.Gray, ConsoleColor.Black);
    }

    public int PedirUsuario(ListaDeUsuarios usuarios)
    {
        int codigoUsuario = 0;
        string nombreUsuario = gp.Pedir(XDATO, YDATO, XMAXIMA, "Introduce " +
            "el nombre del usuario o Intro para continuar: ", ConsoleColor.Black);
        if (nombreUsuario != "")
        {
            codigoUsuario = usuarios.ObtenerCodigoUsuario(nombreUsuario);
        }

        return codigoUsuario;
    }

    public byte RecogerOpcionTicket(ref int ticketActual, Usuario usuario,
        ListaDeTickets listaTickets, ListaDeArticulos listaArticulos)
    {
        byte opcion = 0;
        ConsoleKeyInfo tecla;

        if (Console.KeyAvailable)
        {
            tecla = Console.ReadKey(true);
            if (tecla.KeyChar >= '1' && tecla.KeyChar <= '4')
                opcion = (byte)(tecla.KeyChar - '0');
            else if (tecla.Key == ConsoleKey.DownArrow)
            {
                if (ticketActual < tickets.Tickets.Count - 1)
                {
                    ticketActual++;
                    MostrarPantallaTicketsVacia();
                    gp.MostrarTicket(XDATO, YDATO, tickets.Tickets[ticketActual], 
                        usuario, listaArticulos);
                }
            }
            else if (tecla.Key == ConsoleKey.UpArrow)
            {
                if (ticketActual > 0)
                {
                    ticketActual--;
                    MostrarPantallaTicketsVacia();
                    gp.MostrarTicket(XDATO, YDATO, tickets.Tickets[ticketActual], 
                        usuario, listaArticulos);
                }
            }
        }
        return opcion;
    }

    public byte RecogerOpcionTicket(ref int ticketActual, ListaDeUsuarios usuarios,
        ListaDeArticulos listaArticulos, ListaDeTickets ticketsFiltrados)
    {
        byte opcion = 0;
        ConsoleKeyInfo tecla;

        if (Console.KeyAvailable)
        {
            tecla = Console.ReadKey(true);
            if (tecla.KeyChar >= '1' && tecla.KeyChar <= '5')
                opcion = (byte)(tecla.KeyChar - '0');
            else if (tecla.Key == ConsoleKey.DownArrow)
            {
                if (ticketActual < ticketsFiltrados.Tickets.Count - 1)
                {
                    ticketActual++;
                    MostrarPantallaTicketsVacia();
                    int codigoUsuario =
                        ticketsFiltrados.Tickets[ticketActual].CodigoUsuario;

                    UsuarioGenerico usuario;
                    if (codigoUsuario == 0)
                        usuario = invitado;
                    else
                        usuario = usuarios.GetUsuario(codigoUsuario);

                    gp.MostrarTicket(XDATO, YDATO, 
                        ticketsFiltrados.Tickets[ticketActual], usuario, 
                        listaArticulos);
                }
            }
            else if (tecla.Key == ConsoleKey.UpArrow)
            {
                if (ticketActual > 0)
                {
                    ticketActual--;
                    MostrarPantallaTicketsVacia();
                    int codigoUsuario =
                        ticketsFiltrados.Tickets[ticketActual].CodigoUsuario;

                    UsuarioGenerico usuario;
                    if (codigoUsuario == 0)
                        usuario = invitado;
                    else
                        usuario = usuarios.GetUsuario(codigoUsuario);
                    
                    gp.MostrarTicket(XDATO, YDATO, 
                        ticketsFiltrados.Tickets[ticketActual], usuario, 
                        listaArticulos);
                }
            }
        }
        return opcion;
    }

    public string FechaFormateada(DateTime fecha)
    {
        return fecha.ToString("dd/MM/yyyy");
    }

    public bool Salir()
    {
        return true;
    }
}