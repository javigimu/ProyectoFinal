﻿using System;
using System.Collections.Generic;

class GestorDeArticulos
{
    private const string FICHERO_ARTICULOS = "datos/articulos.txt";

    private ListaDeArticulos articulos = new ListaDeArticulos();

    private string[] opcionesArticulo = {"Añadir", "Modificar", 
        "Modificar stock", "Borrar", "Buscar", "Menu principal"};
    private GestorPantalla gp = new GestorPantalla();

    const int XLISTADO = 5;
    const int YLISTADO = 2;
    const int XDATO = 50;
    const int YDATO = 4;
    const int XMAXIMA = 110;
    const int XDATO_AUXILIAR = 85;

    public ListaDeArticulos GetListaDeArticulos() { return articulos; }
    public void SetListaDeArticulos(ListaDeArticulos articulos)
    {
        this.articulos = articulos;
    }

    // Estructura del fichero de usuarios: codigo;detalle;precio;stock
    public void InicializarArticulos()
    {
        articulos.CargarArticulos(FICHERO_ARTICULOS);
    }

    public void MostrarPantallaArticulos(int articuloActual)
    {
        Console.BackgroundColor = gp.ColorFondoOriginal;
        Console.ForegroundColor = gp.ColorTextoOriginal;
        Console.Clear();
        GestionGYM.MostrarCabecera();
        GestionGYM.MostrarMenu(opcionesArticulo);        

        int yArticuloActual = gp.MostrarArticulos(XLISTADO, YLISTADO, 
            ref articuloActual, articulos);

        gp.MostrarExportar();

        bool volverAlMenuPrincipal;
        do
        {
            int opcion = RecogerOpcionArticulo(ref articuloActual);
            volverAlMenuPrincipal = EjecutarOpcionArticulo(opcion, 
                articuloActual,ref yArticuloActual);
        }
        while (!volverAlMenuPrincipal);
        GestionGYM.LanzarPantallaPrincipal();
        //GestionGYM.MostrarBienvenida();
    }

    public bool EjecutarOpcionArticulo(int opcion, int articuloActual, 
        ref int yArticuloActual)
    {
        bool volverAlMenuPrincipal = false;

        switch (opcion)
        {
            case 0: Exportar(); break;
            case 1: AnyadirArticulo(ref articuloActual); break;
            case 2: ModificarArticulo(articuloActual); break;
            case 3: ModificarStock(articuloActual, yArticuloActual); break;
            case 4: BorrarArticulo(ref articuloActual); break;
            case 5: BuscarArticulo(ref articuloActual); break;
            case 6: volverAlMenuPrincipal = true; break;
        }
        return volverAlMenuPrincipal;
    }

    public void Exportar()
    {
        ExportadorDeArchivos exportar = new ExportadorDeArchivos();
        exportar.ExportarAPdf(articulos);
    }

    public void BuscarArticulo(ref int articuloActual)
    {
        string detalleBusqueda = gp.Pedir(XDATO-15, YDATO, XMAXIMA, 
            "Artículo a buscar: ", ConsoleColor.DarkRed).ToLower();
        articuloActual = articulos.Buscar(detalleBusqueda);
        gp.BorrarTexto(XLISTADO, YLISTADO + 2, XMAXIMA);
        if (articuloActual == -1)
        {
            gp.EscribirError(XDATO-15, YDATO, "No encontrado",
                ConsoleColor.Black);
            articuloActual = 0;
        }
        MostrarPantallaArticulos(articuloActual);
    }

    public void ModificarStock(int articuloActual, int yArticuloActual)
    {
        if (articulos.Articulos[articuloActual] is Actividad)
        {
            gp.EscribirError(XDATO_AUXILIAR, yArticuloActual, "Error, es " +
                "una actividad", ConsoleColor.DarkRed);
        }
        else
        {
            int nuevoStock = gp.PedirNuevoStock(XDATO_AUXILIAR, yArticuloActual,
                XMAXIMA, articulos.Articulos[articuloActual].Stock);
            articulos.Articulos[articuloActual].Stock = nuevoStock;
            articulos.GuardarArticulos(FICHERO_ARTICULOS);
            MostrarPantallaArticulos(articuloActual);
        }
    }

    public void VerAgotados(ref int articuloActual)
    {
        gp.BorrarDatosArticulos(XDATO, YDATO);
        List<Articulo> articulosAgotados = articulos.MostrarAgotados();
        if (articulosAgotados.Count > 0)
        {
            articuloActual = 0;
            ListaDeArticulos listaAgotados = new ListaDeArticulos(articulosAgotados);
            gp.MostrarArticulos(XLISTADO, YLISTADO, ref articuloActual, listaAgotados);
        }
    }

    public void BorrarArticulo(ref int articuloActual)
    {
        articulos.BorrarArticulo(ref articuloActual);
        articulos.GuardarArticulos(FICHERO_ARTICULOS);
        MostrarPantallaArticulos(articuloActual);
    }

    public void ModificarArticulo(int articuloActual)
    {
        gp.BorrarDatosArticulos(XDATO, YDATO);
        gp.MostrarArticuloActual(XDATO, YDATO, articuloActual, articulos);

        int y = Console.CursorTop + 2;
        gp.Escribir(XDATO, y, "Nuevos datos: ", ConsoleColor.DarkBlue);
        y += 2;
        string detalle = gp.Pedir(XDATO, y, XMAXIMA, "Detalle: ",
            ConsoleColor.Black, articulos.Articulos[articuloActual].Detalle);
        float precio = Convert.ToSingle(gp.Pedir(XDATO, y + 2, XMAXIMA, "Precio: ",
            ConsoleColor.Black, "" + articulos.Articulos[articuloActual].Precio));
        int numStock;
        do
        {
            string stock = gp.Pedir(XDATO, y + 4, XMAXIMA, "Stock: ",
                ConsoleColor.Black, "" + articulos.Articulos[articuloActual].Stock);
            if (!Int32.TryParse(stock, out numStock))
                numStock = -1;
        }
        while (numStock == -1);

        articulos.Modificar(articuloActual, detalle, precio, numStock);
        articulos.GuardarArticulos(FICHERO_ARTICULOS);
        MostrarPantallaArticulos(articuloActual);
    }

    public void AnyadirArticulo(ref int articuloActual)
    {
        gp.BorrarDatosArticulos(0, 2);
        int codigo = articulos.getUltimoCodigo();
        string detalle = gp.Pedir(XDATO, YDATO, XMAXIMA, "Detalle: ",
           ConsoleColor.Black);
        float precio = Convert.ToSingle(
            gp.Pedir(XDATO, YDATO, XMAXIMA, "Precio: ", ConsoleColor.Black));

        int numStock;
        string esActividad = gp.Pedir(XDATO, YDATO, XMAXIMA,
            "Es una activiad? (s/n)", ConsoleColor.Black);
        if (esActividad.StartsWith('s'))
        {
            articulos.AnyadirArticulo(new Actividad(codigo, detalle, precio));
        }
        else
        {
            do
            {
                string stock = gp.Pedir(XDATO, YDATO, XMAXIMA, "Stock: ",
                    ConsoleColor.Black);
                if (!Int32.TryParse(stock, out numStock))
                    numStock = -1;
            }
            while (numStock == -1);

            articulos.AnyadirArticulo(new Articulo(codigo, detalle, precio, numStock));
        }
        articulos.GuardarArticulos(FICHERO_ARTICULOS);
        articuloActual = 0;
        MostrarPantallaArticulos(articuloActual);
    }

    public int RecogerOpcionArticulo(ref int articuloActual)
    {
        int opcion = -1;
        ConsoleKeyInfo tecla;

        if (Console.KeyAvailable)
        {
            tecla = Console.ReadKey(true);
            if (tecla.KeyChar >= '0' && tecla.KeyChar <= '6')
                opcion = (byte)(tecla.KeyChar - '0');
            else if (tecla.Key == ConsoleKey.DownArrow)
            {
                if (articuloActual < articulos.Articulos.Count - 1)
                {
                    articuloActual++;
                    MostrarPantallaArticulos(articuloActual);
                }
            }
            else if (tecla.Key == ConsoleKey.UpArrow)
            {
                if (articuloActual > 0)
                {
                    articuloActual--;
                    MostrarPantallaArticulos(articuloActual);
                }
            }
        }
        return opcion;
    }

    public byte RecogerOpcion()
    {
        byte opcion = 0;
        ConsoleKeyInfo tecla;

        if (Console.KeyAvailable)
        {
            tecla = Console.ReadKey(true);
            if (tecla.KeyChar >= '1' && tecla.KeyChar <= '7')
                opcion = (byte)(tecla.KeyChar - '0');
        }
        return opcion;
    }

    public ListaDeArticulos ObtenerArticulosPorDetalle(string detalle)
    {
        ListaDeArticulos articulosFiltrados = new ListaDeArticulos();
        foreach (Articulo a in articulos.Articulos)
        {
            if (a.Detalle.ToLower().Contains(detalle.ToLower()))
                articulosFiltrados.Articulos.Add(a);
        }
        return articulosFiltrados;
    }

    public bool Salir()
    {
        return true;
    }
}